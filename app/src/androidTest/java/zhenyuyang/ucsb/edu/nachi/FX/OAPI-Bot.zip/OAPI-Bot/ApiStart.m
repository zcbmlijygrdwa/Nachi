addpath 'libs';
addpath 'tools';
javaaddpath('libs/lib/httpclient-4.3.3.jar');
javaaddpath('libs/lib/httpclient-cache-4.3.3.jar');
javaaddpath('libs/lib/commons-cli-1.2.jar');
javaaddpath('libs/lib/commons-codec-1.6.jar');
javaaddpath('libs/lib/commons-logging-1.1.3.jar');
javaaddpath('libs/lib/fluent-hc-4.3.3.jar');
javaaddpath('libs/lib/httpcore-4.3.2.jar');
javaaddpath('libs/lib/httpcore-ab-4.3.2.jar');
javaaddpath('libs/lib/httpcore-nio-4.3.2.jar');
javaaddpath('libs/lib/httpmime-4.3.3.jar');
javaaddpath('libs/lib/json-simple-1.1.1.jar');
javaaddpath('libs/lib/commons-io-2.4.jar');
api = api;
disp('OAPI is ready to connect')